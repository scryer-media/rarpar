# Native macOS reference build

This is a benchmark-only portability adaptation of official par3cmdline
revision `2971702e501f1350b1c7b9d11369af9157d6ed56`, not an upstream-supported
macOS release. No algorithm bodies were changed. The patch and this recipe
apply only to a separate reference checkout, never to the Rust engine.

The official archive SHA-256 is
`41695d424730bfa4838bada4f2750928f895ff8cf5cb6e6dc81ebe89731c6e8d`.

1. Extract that revision into a new scratch directory. From its root, apply
   `reference-macos.patch` with `patch -p1 < /path/to/reference-macos.patch`.
   The patch has zero context and changes only platform selection, POSIX
   headers/timestamps, CMake source/flag selection, a SIMD include, and a
   compile-time symbol alias.
2. Create `src/leopard/sse2neon/` and download `sse2neon.h` from
   <https://raw.githubusercontent.com/DLTcollab/sse2neon/5abe11523bf6110297812e2a8c1e7c67b8903379/sse2neon.h>.
   Its SHA-256 must be
   `5d22f47a74f012de1f1ea84926ad4e8d13871298af9f99179f61fed380beb34d`.
   This upstream MIT-licensed header is retained only in the scratch build;
   its license notice remains in the downloaded file.
3. Use the already installed Homebrew LLVM 22.1.8 and libomp 22.1.7:

```sh
cmake -S src -B build -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_C_COMPILER=/opt/homebrew/opt/llvm/bin/clang \
  -DCMAKE_CXX_COMPILER=/opt/homebrew/opt/llvm/bin/clang++ \
  '-DCMAKE_C_FLAGS=-mcpu=native -fopenmp -D_DARWIN_C_SOURCE' \
  '-DCMAKE_CXX_FLAGS=-mcpu=native -fopenmp' \
  '-DCMAKE_EXE_LINKER_FLAGS=-fopenmp -L/opt/homebrew/opt/libomp/lib'
cmake --build build -j4
```

Leopard's existing ARM path uses SSE2NEON. The pinned archive lacks BLAKE3's
NEON source, so its existing SSE2 translation unit uses the same header and
exports `blake3_hash_many_sse2` under the `blake3_hash_many_neon` symbol expected
by ARM dispatch. Both have a SIMD degree of four. Single-block compression
retains the pinned ARM dispatcher’s portable path. This is translated SSE2
hashing, not upstream's dedicated NEON implementation; retain that qualification
when comparing throughputs. No additional BLAKE3 source was introduced.

The final matrix checks reference verification of every Rust-created set and
Rust verification of every reference-created set, then confirms both engines'
repairs against independently saved SHA-256 input digests. A prior complete
run using portable-only reference hashing passed but is excluded from reported
comparisons. Pilot and portable-only timings are not in this evidence archive.

# PAR3 native tuning evidence, 2026-09-08

Runtime sources are reproduced by applying `tuning.patch` to repository revision
`10b1640`. The carrier read-ahead slice is also recorded in signed revision
`276c7c1`; subsequent runtime changes were measured from the working tree.
The patch includes regression tests and the exact benchmark example. Later
README and crate-level rustdoc status edits have no runtime changes.

Both hosts used the same native build settings and reference binaries as the
earlier `native-x86-20260908.tar.gz` and `native-arm64-20260908.tar.gz` evidence.
The latter preserves the approved scratch macOS reference adaptation and header
provenance. No additional third-party changes occurred in this tuning pass.
Binary hashes are stored under each host. Rust was built with
`RUSTFLAGS='-C target-cpu=native' cargo build --locked --release -p par3-rs --example engine_perf`.

`arm64/default/final` and `x86/default/final` each contain 534 successful
measurements, nine cases, workers 1 and 4, three repetitions. The supplied
`run_native.py` reproduces the matrix with explicit engine/reference/output
paths; Linux additionally uses `--cpus 0,2,4,6`. Existing file synchronization
defaults were used. Each `summary.json` comes from its sibling `summarize.py`.
`comparison.json` compares with the earlier host-specific archive using
`compare.py`. Original historical comparisons remain intact.

`arm64/ab` holds seven interleaved baseline/tuned repetitions for 32 Cauchy
operation/worker/workload combinations (448 invocations). Its script verifies
every repaired output digest. `x86/ab` holds fifteen pairs for the Cauchy GF8
four-worker verification discrepancy (30 invocations). These checks investigate
historical increases above 5%; they are not added to reference aggregates.
Baseline binaries were rebuilt from the pre-tuning runtime sources under the
same native toolchains. Paths in raw commands identify scratch directories used
during measurement, not installation requirements.

`arm64/create-ab` adds seven old/new Cauchy GF16 four-worker creation pairs,
with reference verification of all fourteen sets. It excludes an earlier
exploratory run that overlapped a rustdoc build. The archived final repetition
ran after that build finished.

`arm64/buffered` separately measures the four FFT cases with
`PAR3_BENCH_CREATE_DURABILITY=buffered`, two worker limits and three repetitions
(240 invocations). Creation records explicitly include Buffered and zero sync
calls. Verification and repair policies are unchanged. These records do not
replace or mix with the default-durability matrix.

The archive contains timing logs, RSS, input digests, scripts, source changes,
and validation logs. It contains no generated protected inputs, recovery
carriers, rebuilt outputs, executables, or downloaded third-party source.
The short macOS sample is an attribution probe, excluded from every timing
aggregate. Stage durations may nest; never add them as exclusive wall time.

Validation: workspace formatting and all-target/all-feature Clippy passed;
2,546 workspace Nextest tests passed with 12 existing opt-in skips; 24 doctests
passed with one ignored host-hook example. All four real-world PAR2 consumer
regressions are included in the workspace results. Runtime code did not change
after this validation.

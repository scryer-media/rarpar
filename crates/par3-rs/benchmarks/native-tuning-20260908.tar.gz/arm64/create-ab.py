import json
from pathlib import Path
import statistics
import subprocess
import time

root=Path('/tmp/par3-tuned-mac-create-ab-final')
root.mkdir(exist_ok=False)
data=Path('/tmp/par3-tuned-mac-final/final/cauchy-gf16-w4/original')
binaries={'baseline':'/tmp/par3-mac-baseline-build/release/examples/engine_perf',
          'tuned':'/tmp/par3-mac-native-build/release/examples/engine_perf'}
rows=[]
for repetition in range(7):
    for name in (list(binaries) if repetition%2==0 else list(reversed(binaries))):
        out=root/f'{name}-{repetition}'
        out.mkdir();scratch=out/'scratch';scratch.mkdir()
        command=[binaries[name],'create',str(data),str(out),str(scratch),'4','256','cauchy','65536','32','0']
        started=time.perf_counter()
        result=subprocess.run(['/usr/bin/time','-l','-p',*command],capture_output=True,text=True,timeout=60)
        elapsed=time.perf_counter()-started
        (out/'create.log').write_text(result.stdout+result.stderr)
        assert result.returncode==0
        check=subprocess.run(['/tmp/par3-mac-native-reference/build/par3cmd/par3','v','-S0',f'-B{data}',str(out/'set.par3')],capture_output=True,text=True,timeout=60)
        (out/'reference-verify.log').write_text(check.stdout+check.stderr)
        assert check.returncode==0
        rows.append(dict(engine=name,repetition=repetition,wall_seconds=elapsed,command=command))
summary={name:statistics.median(r['wall_seconds'] for r in rows if r['engine']==name)*1000 for name in binaries}
summary['change_percent']=(summary['tuned']/summary['baseline']-1)*100
(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(summary)

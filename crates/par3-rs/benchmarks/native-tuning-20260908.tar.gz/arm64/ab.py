"""Interleaved old/new process comparisons over retained official carriers."""
import hashlib
import json
from pathlib import Path
import statistics
import subprocess
import time

inputs = Path('/tmp/par3-tuned-mac-final/final')
root = Path('/tmp/par3-tuned-mac-ab')
root.mkdir(exist_ok=False)
binaries = {'baseline': '/tmp/par3-mac-baseline-build/release/examples/engine_perf',
            'tuned': '/tmp/par3-mac-native-build/release/examples/engine_perf'}
rows = []
for case in ('cauchy-gf8', 'cauchy-gf16', 'cauchy-heavy', 'large-block-small-budget'):
    for workers in (1, 4):
        source = inputs / f'{case}-w{workers}'
        trial = source / 'trial0'
        memory = 64 if case == 'cauchy-heavy' else 8 if case == 'large-block-small-budget' else 256
        expected = json.loads((source / 'input-sha256.json').read_text())
        for operation in ('scan', 'verify', 'placement', 'repair'):
            for repetition in range(7):
                order = list(binaries) if repetition % 2 == 0 else list(reversed(binaries))
                for name in order:
                    label = f'{case}-w{workers}-{operation}-r{repetition}-{name}'
                    out = root / label
                    out.mkdir()
                    data = trial / 'damaged' if operation == 'repair' else source / 'original'
                    command = [binaries[name], operation, str(data), str(trial / 'reference'), str(out), str(workers), str(memory)]
                    start = time.perf_counter()
                    child = subprocess.run(['/usr/bin/time', '-l', '-p', *command], capture_output=True, text=True, timeout=120)
                    elapsed = time.perf_counter() - start
                    (root / (label + '.log')).write_text(child.stdout + child.stderr)
                    assert child.returncode == 0, child.stderr
                    if operation == 'repair':
                        for filename, digest in expected.items():
                            assert hashlib.sha256((out / filename).read_bytes()).hexdigest() == digest
                    metrics = [json.loads(s) for s in child.stdout.splitlines() if s.startswith('{')]
                    row = dict(case=case, workers=workers, operation=operation, repetition=repetition,
                               engine=name, wall_seconds=elapsed, metrics=metrics, command=command)
                    rows.append(row)
                    with (root / 'results.jsonl').open('a') as stream:
                        stream.write(json.dumps(row) + '\n')
            old = statistics.median(r['wall_seconds'] for r in rows if (r['case'],r['workers'],r['operation'],r['engine']) == (case,workers,operation,'baseline'))
            new = statistics.median(r['wall_seconds'] for r in rows if (r['case'],r['workers'],r['operation'],r['engine']) == (case,workers,operation,'tuned'))
            print(json.dumps(dict(case=case,workers=workers,operation=operation,baseline_ms=old*1000,tuned_ms=new*1000,change_percent=(new/old-1)*100)),flush=True)

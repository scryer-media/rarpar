import collections
import json
import math
from pathlib import Path
import statistics

root = Path(__file__).parent
rows = [json.loads(s) for s in (root / 'final/results.jsonl').read_text().splitlines()]
assert len(rows) == 534, len(rows)
assert all(r['exit_code'] == 0 for r in rows)
groups = collections.defaultdict(list)
for row in rows:
    groups[row['case'], row['workers'], row['label']].append(row)
assert all(len(values) == 3 for values in groups.values())
cases = list(dict.fromkeys(r['case'] for r in rows))

def med(case, workers, label):
    return statistics.median(r['wall_seconds'] for r in groups[case, workers, label])

ratios = []
for codec in ('cauchy', 'fft'):
    names = [c for c in cases if groups[c, 1, 'rust-create'][0]['codec'] == codec]
    for workers in (1, 4):
        entry = dict(codec=codec, workers=workers)
        for operation in ('create', 'verify', 'repair'):
            entry[operation] = math.exp(statistics.mean(math.log(
                med(c, workers, 'reference-' + operation) / med(c, workers, 'rust-' + operation)
            ) for c in names))
        ratios.append(entry)

times = []
for case in cases:
    for workers in (1, 4):
        entry = dict(case=case, workers=workers)
        for operation in ('create', 'verify', 'repair', 'scan', 'placement'):
            for engine in ('rust', 'reference'):
                label = engine + '-' + operation
                if (case, workers, label) in groups:
                    entry[label + '_ms'] = med(case, workers, label) * 1000
        times.append(entry)

stage_times = []
for (case, workers, label), values in groups.items():
    if not label.startswith('rust-'):
        continue
    stages = collections.defaultdict(list)
    for value in values:
        for item in value['engine_metrics']:
            stage = item.get('stage') or item.get('internal_stage')
            if stage:
                stages[stage].append(item['seconds'] * 1000)
    stage_times.append(dict(case=case, workers=workers, operation=label,
                           median_ms={s: statistics.median(v) for s, v in stages.items()}))

memory = []
for case in cases:
    values = [r for r in rows if r['case'] == case]
    metrics = [item for r in values for item in r['engine_metrics']]
    limit = values[0]['memory_mib'] * (1 << 20)
    peak = max(m.get('reserved_peak', 0) for m in metrics)
    handles = max(m.get('handle_peak', 0) for m in metrics)
    assert peak <= limit, (case, peak, limit)
    memory.append(dict(case=case, budget_mib=values[0]['memory_mib'],
                       reserved_peak_mib=peak / (1 << 20), handle_peak=handles,
                       **{label + '_max_rss_mib': max(r['max_rss_kib'] for r in values if r['label'] == label) / 1024
                          for label in ('rust-repair', 'reference-repair')}))

reassess = [r for r in rows if r['label'] == 'rust-reassess']
assert len(reassess) == 54
for r in reassess:
    admitted = [m for m in r['engine_metrics'] if m.get('stage') == 'reassess_100']
    assert len(admitted) == 1, r
    assert admitted[0]['source_read_bytes'] == admitted[0]['source_read_calls'] == 0
small = [r for r in rows if r['case'] == 'many-small-files' and r['label'] == 'rust-repair']
assert all(any(m.get('installed') == 64 for m in r['engine_metrics']) for r in small)
summary = dict(commands=len(rows), geometric_mean_ratios=ratios, median_times=times,
               stage_times=stage_times, memory=memory,
               load_range=[min(r['load_average'][0] for r in rows), max(r['load_average'][0] for r in rows)])
(root / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({k: v for k, v in summary.items() if k != 'stage_times'}, indent=2))

import json
from pathlib import Path
import statistics
import subprocess
import time

root = Path('/tmp/par3-native-perf-20260908.3Bgo8s')
out = root / 'tuned/ab'
out.mkdir(exist_ok=False)
case = root / 'tuned/final/cauchy-gf8-w4'
rows = []
for repetition in range(15):
    order = ('baseline', 'tuned') if repetition % 2 == 0 else ('tuned', 'baseline')
    for name in order:
        command = [str(root / ('engine_perf-' + name)), 'verify', str(case / 'original'),
                   str(case / 'trial0/reference'), str(out), '4', '256']
        started = time.perf_counter()
        result = subprocess.run(['taskset', '-c', '0,2,4,6', *command], capture_output=True, text=True, timeout=60)
        elapsed = time.perf_counter() - started
        (out / f'{name}-{repetition}.log').write_text(result.stdout + result.stderr)
        assert result.returncode == 0
        rows.append(dict(engine=name,repetition=repetition,wall_seconds=elapsed,command=command))
summary = {name: statistics.median(r['wall_seconds'] for r in rows if r['engine']==name)*1000 for name in ('baseline','tuned')}
summary['change_percent'] = (summary['tuned']/summary['baseline']-1)*100
(out / 'results.json').write_text(json.dumps(rows,indent=2)+'\n')
(out / 'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(summary)

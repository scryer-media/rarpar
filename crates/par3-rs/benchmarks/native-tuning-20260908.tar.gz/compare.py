import collections
import json
import math
from pathlib import Path
import statistics
import sys
import tarfile

root, archive = map(Path, sys.argv[1:3])
with tarfile.open(archive) as source:
    baseline = [json.loads(s) for s in source.extractfile('final/results.jsonl').read().splitlines()]
current = [json.loads(s) for s in (root / 'final/results.jsonl').read_text().splitlines()]
assert len(current) == 534 and all(r['exit_code'] == 0 for r in current)
def group(rows):
    groups = collections.defaultdict(list)
    for row in rows:
        groups[row['case'], row['workers'], row['label']].append(row)
    assert all(len(v) == 3 for v in groups.values())
    return groups
old, new = group(baseline), group(current)
med = lambda rows: statistics.median(r['wall_seconds'] for r in rows)
changes = []
for key, rows in new.items():
    if key[2].startswith('rust-'):
        changes.append(dict(case=key[0], workers=key[1], operation=key[2],
                            previous_ms=med(old[key])*1000, tuned_ms=med(rows)*1000,
                            change_percent=(med(rows)/med(old[key])-1)*100,
                            reference_change_percent=(med(new[(key[0],key[1],key[2].replace('rust-', 'reference-'))])/med(old[(key[0],key[1],key[2].replace('rust-', 'reference-'))])-1)*100 if (key[0],key[1],key[2].replace('rust-', 'reference-')) in new else None))
(root / 'comparison.json').write_text(json.dumps(changes, indent=2)+'\n')
print(json.dumps([r for r in changes if r['change_percent'] > 5], indent=2))
